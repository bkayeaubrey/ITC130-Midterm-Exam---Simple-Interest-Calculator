import 'package:flutter/material.dart';

void main() {
  runApp(SimpleInterestCalculator());
}

class SimpleInterestCalculator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Simple Interest Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: InterestCalculatorScreen(),
    );
  }
}

class InterestCalculatorScreen extends StatefulWidget {
  @override
  _InterestCalculatorScreenState createState() => _InterestCalculatorScreenState();
}

class _InterestCalculatorScreenState extends State<InterestCalculatorScreen> {
  final _principalController = TextEditingController();
  final _rateController = TextEditingController();
  final _timeController = TextEditingController();
  String _result = '';
  String _currentInput = '';
  TextEditingController? _currentController;

  void _onNumberPress(String number) {
    setState(() {
      _currentInput += number;
      _currentController?.text = _currentInput;
    });
  }

  void _onBackspace() {
    setState(() {
      if (_currentInput.isNotEmpty) {
        _currentInput = _currentInput.substring(0, _currentInput.length - 1);
        _currentController?.text = _currentInput;
      }
    });
  }

  void _calculateInterest() {
    final double principal = double.tryParse(_principalController.text) ?? 0.0;
    final double rate = double.tryParse(_rateController.text) ?? 0.0;
    final double time = double.tryParse(_timeController.text) ?? 0.0;

    // Converting time period from months to years
    final double timeInYears = time / 12;

    final double interest = (principal * rate * timeInYears) / 100;
    final double totalAmount = principal + interest;

    setState(() {
      _result = 'Interest = ₱${interest.toStringAsFixed(2)}\n'
                'Total Maturity Payment = ₱${totalAmount.toStringAsFixed(2)}';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Simple Interest Calculator'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _principalController,
              decoration: InputDecoration(
                labelText: 'Principal Amount (₱)',
                border: OutlineInputBorder(),
              ),
              onTap: () => setState(() {
                _currentController = _principalController;
                _currentInput = _principalController.text;
              }),
              readOnly: true,
            ),
            SizedBox(height: 16),
            TextField(
              controller: _rateController,
              decoration: InputDecoration(
                labelText: 'Rate of Interest (%)',
                border: OutlineInputBorder(),
              ),
              onTap: () => setState(() {
                _currentController = _rateController;
                _currentInput = _rateController.text;
              }),
              readOnly: true,
            ),
            SizedBox(height: 16),
            TextField(
              controller: _timeController,
              decoration: InputDecoration(
                labelText: 'Time Period (months)',
                border: OutlineInputBorder(),
              ),
              onTap: () => setState(() {
                _currentController = _timeController;
                _currentInput = _timeController.text;
              }),
              readOnly: true,
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildNumberButton('7'),
                _buildNumberButton('8'),
                _buildNumberButton('9'),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildNumberButton('4'),
                _buildNumberButton('5'),
                _buildNumberButton('6'),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildNumberButton('1'),
                _buildNumberButton('2'),
                _buildNumberButton('3'),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildNumberButton('.'),
                _buildNumberButton('0'),
                _buildActionButton('⌫', _onBackspace),
              ],
            ),
           
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: _calculateInterest,
              child: Text('Calculate Interest'),
            ),
            SizedBox(height: 16),
            Text(
              _result,
              style: TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNumberButton(String number) {
    return SizedBox(
      width: 70,
      height: 70,
      child: ElevatedButton(
        onPressed: () => _onNumberPress(number),
        child: Text(number, style: TextStyle(fontSize: 20)),
      ),
    );
  }

  Widget _buildActionButton(String label, VoidCallback onPressed) {
    return SizedBox(
      width: 70,
      height: 70,
      child: ElevatedButton(
        onPressed: onPressed,
        child: Text(label, style: TextStyle(fontSize: 24)),
      ),
    );
  }

  @override
  void dispose() {
    _principalController.dispose();
    _rateController.dispose();
    _timeController.dispose();
    super.dispose();
  }
}
